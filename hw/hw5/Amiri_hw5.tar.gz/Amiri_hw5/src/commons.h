/*
 * commons.h
 *
 *  Created on: Mar 13, 2016
 *      Author: roohi
 */

#ifndef COMMONS_H_
#define COMMONS_H_

#define RADIUS        3
#define BLOCK_SIZE    1024
#define MICRO "\u03bc"

const char separator = ' ';
const int nameWidth  = 6;



#endif /* COMMONS_H_ */
